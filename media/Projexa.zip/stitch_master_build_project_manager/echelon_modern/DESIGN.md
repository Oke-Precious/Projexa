# Design System Strategy: Atmospheric Precision

## 1. Overview & Creative North Star
This design system is built upon the North Star of **"Atmospheric Precision."** In a market saturated with rigid, grid-locked project management tools, we distinguish ourselves by blending the high-end editorial feel of a luxury digital magazine with the lightning-fast responsiveness of a modern startup environment.

We break the "SaaS template" look by prioritizing negative space as a functional element rather than a void. By utilizing intentional asymmetry, overlapping layers, and a sophisticated hierarchy of light, we create an environment that feels breathable yet authoritative. This is not just a tool; it is a curated workspace designed to reduce cognitive load and elevate the act of management into an art form.

## 2. Colors: Tonal Architecture
The palette is rooted in deep, intellectual violets and electric blues, balanced by an expansive range of "cool-neutral" surfaces that provide a fresh, airy foundation.

### The "No-Line" Rule
To achieve a premium, seamless aesthetic, **1px solid borders are strictly prohibited** for sectioning or layout containment. Boundaries must be defined through:
*   **Background Shifts:** Distinguish a sidebar from a main stage by placing a `surface` section against a `surface-container-low` background.
*   **Tonal Transitions:** Use the natural contrast between `surface-container-highest` and `surface-container-lowest` to define interactive zones.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of semi-translucent materials.
*   **Base:** `background` (#f8f9ff).
*   **Secondary Zones (Sidebars/Kanban Tracks):** `surface-container-low` (#eff4ff).
*   **Primary Interactive Elements (Cards):** `surface-container-lowest` (#ffffff).
*   **Active/Floating States:** `surface-bright` (#f8f9ff).

### The "Glass & Gradient" Rule
To provide "soul" to the professional interface:
*   **Glassmorphism:** Use `surface` colors at 70% opacity with a `24px` backdrop-blur for floating headers or navigation overlays.
*   **Signature Gradients:** Main CTAs and high-level progress indicators should use a subtle linear gradient from `primary` (#4648d4) to `primary_container` (#6063ee) at a 135-degree angle. This adds a sense of forward momentum.

## 3. Typography: Editorial Authority
We utilize **Inter** not as a default, but as a precision instrument. The scale is designed to create a clear narrative path for the user’s eye.

*   **The Power Scale:** Use `display-lg` (3.5rem) for high-level project milestones and `headline-lg` (2rem) for dashboard titles. These should be set with tight letter-spacing (-0.02em) to feel impactful and modern.
*   **Functional Clarity:** `body-md` (0.875rem) is the workhorse for task descriptions, providing high readability without crowding the screen.
*   **The Metadata Layer:** `label-sm` (0.6875rem) in `on-surface-variant` should be used for timestamps and secondary tags. This creates a sophisticated contrast against the larger, bolder headings.

## 4. Elevation & Depth
Hierarchy in this system is achieved through **Tonal Layering** rather than structural scaffolding.

### The Layering Principle
Instead of shadows, use the "Step-Up" method:
1.  **Level 0:** `surface-container-low` (The "Floor")
2.  **Level 1:** `surface-container-lowest` (The "Card")
3.  **Level 2:** `surface-container-high` (The "Active State")

### Ambient Shadows
When an element must "float" (e.g., a context menu or a dragged task card), use an **Ambient Shadow**:
*   **Color:** Use a tinted version of `on-surface` (#0b1c30) at 6% opacity.
*   **Blur:** 32px to 48px.
*   **Spread:** -4px.
This creates a soft, natural lift that mimics studio lighting rather than a dated "drop shadow."

### The "Ghost Border" Fallback
If a border is required for accessibility (e.g., in a high-density table), use a **Ghost Border**:
*   **Token:** `outline-variant` (#c7c4d7) at **15% opacity**. It should be felt, not seen.

## 5. Components: Fluid Primitives

### Buttons: The Kinetic Core
*   **Primary:** A gradient fill (`primary` to `primary_container`) with `xl` (1.5rem) roundedness. This "pill" shape feels approachable and fast.
*   **Secondary:** No fill. Use `surface-container-highest` as a background with `on-surface` text.
*   **Interaction:** On hover, primary buttons should expand slightly (1.02 scale) and increase shadow diffusion.

### Task Cards: Nested Clarity
*   **Container:** Use `surface-container-lowest` with `md` (0.75rem) corners.
*   **Separation:** Strictly forbid divider lines. Use `16px` of vertical white space to separate the task title from the assignee avatars.
*   **Status Indicators:** Use `tertiary` (#006577) for "In Progress" and `secondary` (#6b38d4) for "Review," applied as small, vibrant pips or high-contrast chips.

### Kanban Columns: Immersive Tracks
*   **Background:** `surface-container-low`.
*   **Header:** Use `title-sm` (1rem) in `primary` to ensure the column identity is clear at a glance.
*   **Spacing:** Ensure `24px` gutters between columns to allow the `background` to "breathe" through the layout.

### Input Fields: Soft Focus
*   **Fill:** `surface-container-highest`.
*   **Border:** None.
*   **Focus State:** A 2px "Ghost Border" using `primary` at 40% opacity and a subtle `primary_fixed` inner glow.

### Profile Avatars
*   **Shape:** `full` (9999px) roundedness.
*   **Border:** A 2px "ring" using the `surface` color to separate overlapping avatars in a team pile-up.

## 6. Do’s and Don'ts

### Do
*   **Do** use asymmetrical margins to create visual interest in dashboard layouts.
*   **Do** leverage `backdrop-blur` on modals to maintain the user's context of the "work beneath."
*   **Do** use `primary_fixed` backgrounds for subtle highlights on important text.

### Don't
*   **Don't** use 100% black text. Always use `on-surface` (#0b1c30) for a softer, more premium feel.
*   **Don't** use sharp corners. Every interactive element must have at least a `sm` (0.25rem) radius to maintain the "Soft UI" brand promise.
*   **Don't** use standard "dividers" to separate list items. Use tonal shifts or increased padding.
*   **Don't** use high-saturation red for errors unless it’s a critical system failure. Use `error_container` with `on_error_container` for a more sophisticated, "startup-friendly" alert.